# apod.widget
Übersicht APOD desktop image and video

Updated Oct 2025

What's new

Minor update.

All Mac's since OS 10.6 should have everything installed and ready to go (Bash and SIPs (Simple Image Processor)). 
Just configure apod.jsx to suit your tastes.
Get an API key from NASA. It's free and easy. 
I have included a 'default.jpg' which you can replace with anything you like as long as it is called 'default.jpg' and isn't too big (1-3Mb).

Configuration

Only 1 must be changed - the API key. It will be 40 characters long.
Go to https://api.nasa.gov
Fill in the three required fields.
Copy the key into the apod.jsx script. Not the web address, just the key.
Done.

These are 11 lines that control virtually everything. 

export const folder = "/APOD/" // the name of this folder inside your widgets folder

export const durationMs = 60 * 60 * 1000 // how often it checks with NASA for a new image in milliseconds

export const width = 2560 // your screen width

export const height = 1440 // your screen height

export const dock = 90 // height of your dock - so the caption will clear it

export const captionWidth = 450 // or Math.floor(width * .7) for 70% of the screen width. Width of caption

export const videoWidth = Math.floor(width * .6) // .7 = 70% of the screen width. Max width of image on screen

export const margin = 10 // or to centre the caption: Math.floor((width - captionWidth) / 2) - 20 Left margin size.

export const videoMargin = Math.floor((width - videoWidth) / 2) - 20 // margin at sides of video

export const videoTopMargin = 80 // margin at top of video

export const apiKey = "DEMO_KEY" // get your api key at api.nasa.govt (it's free and not hard)

That should do it. I've tested on a few Macs of mine and it worked.

Disclaimer

I have no idea what I'm doing. 
Use this at your own risk. It shouldn't break anything. It doesn't write anything outside of the directory it's installed in. Check the apod.jsx and apod.sh files in a text editor. They are commented as to what is going on.
Rememnber, I wrote it for myself. If it can be improved please help me learn. 
Change it as you wish but please share the improvements with me: github@skunkworks.net.nz
